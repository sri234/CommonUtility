class Demo:
    def __init__(self,name):
        self.name = name

    def check(self):
        print("Hi I am working fine")